<?php
get_header();

echo "<h2 style='text-align:center;margin: 3em auto;'>صفحه پیدا نشد</h2>";

get_footer();
