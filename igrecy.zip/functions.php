<?php

// Include functions
require_once(__DIR__ . "/includes/carbon_fields.php");

// Include functions
require_once(__DIR__ . "/includes/funcs.php");

// Actions
require_once(__DIR__ . "/includes/actions.php");

// Custom Nav walker
require_once(__DIR__ . "/includes/navwalker.php");
